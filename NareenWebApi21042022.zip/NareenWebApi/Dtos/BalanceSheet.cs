﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NareenWebApi.Dtos
{
    public class BalanceSheet
    {
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public String Type { get; set; }
        public decimal CreditAmt { get; set; }
        public decimal DebitAmt { get; set; }
        public decimal Diff { get; set; }
    }
    public class YearlySummarry
    {
        public string MonthName { get; set; }
        public string MonthNumber { get; set; }
        public decimal CreditAmt { get; set; }
        public decimal DebitAmt { get; set; }
        public decimal Diff { get; set; }
    }
}