﻿using Fadel.EmailComponent;
using NareenWebApi.Dtos;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NareenWebApi.DataAcess
{
    //public class DataAcessRepository
    //{
    //}
    public class DataAcessRepository : IDataAcessRepository
    {
        private readonly IDbConnection _db;

        public DataAcessRepository()
        {
            _db = new SqlConnection(ConfigurationManager.ConnectionStrings["FS_Connection"].ConnectionString);
        }


        public object GetYearlySummary(int year)
        {

            ArrayList arrayList3 = new ArrayList();
            arrayList3.Add(year);
            clsLog.WriteInfoLog("{Info} " + DateTime.Now + " - FS_Helper.INSERTRECORDS - SPNAME -Sp_Montly_BalnceSheet_Reports " + year + " - Method Executed.");
            DataSet ds3 = FS_Helper.INSERTRECORDS("Sp_Yearly_Reports", arrayList3);
            List<YearlySummarry> BSE = new List<YearlySummarry>();
            for (int i = 0; i < ds3.Tables[0].Rows.Count; i++)
            {
                YearlySummarry BS = new YearlySummarry();
                BS.MonthName = ds3.Tables[0].Rows[0]["monthname"].ToString();
                BS.MonthNumber = ds3.Tables[0].Rows[0]["number"].ToString();
                BS.CreditAmt = Convert.ToDecimal(ds3.Tables[0].Rows[0]["CreditAmt"].ToString());
                BS.DebitAmt = Convert.ToDecimal(ds3.Tables[0].Rows[0]["DebitAmt"].ToString());
                BS.Diff = Convert.ToDecimal(ds3.Tables[0].Rows[0]["Diff"].ToString());
                BSE.Add(BS);
            }

            return BSE;

        }

        IEnumerable<YearlySummarry> IDataAcessRepository.GetYearlySummary(int year)
        {
            throw new NotImplementedException();
        }

        public object GetMonthlyDetials(int MonthID, int year)
        {

            ArrayList arrayList3 = new ArrayList();
            arrayList3.Add(MonthID);
            arrayList3.Add(year);
            clsLog.WriteInfoLog("{Info} " + DateTime.Now + " - FS_Helper.INSERTRECORDS - SPNAME -Sp_Montly_BalnceSheet_Reports " + MonthID + " - Method Executed.");
            DataSet ds3 = FS_Helper.INSERTRECORDS("Sp_Montly_BalnceSheet_Reports", arrayList3);
            List<BalanceSheet> BSE = new List<BalanceSheet>();
            for (int i = 0; i < ds3.Tables[0].Rows.Count; i++)
            {
                BalanceSheet BS = new BalanceSheet();
                BS.Name = ds3.Tables[0].Rows[0]["Name"].ToString();
                BS.Date = Convert.ToDateTime(ds3.Tables[0].Rows[0]["Date"].ToString());
                BS.Type = ds3.Tables[0].Rows[0]["Type"].ToString();
                BS.CreditAmt = Convert.ToDecimal(ds3.Tables[0].Rows[0]["CreditAmt"].ToString());
                BS.DebitAmt = Convert.ToDecimal(ds3.Tables[0].Rows[0]["DebitAmt"].ToString());
                BS.Diff = Convert.ToDecimal(ds3.Tables[0].Rows[0]["Diff"].ToString());
                BSE.Add(BS);
            }

            return BSE;

        }

        IEnumerable<BalanceSheet> IDataAcessRepository.GetMonthlyDetials(int MonthID, int year)
        {
            throw new NotImplementedException();
        }


        public object GetDailySummary(DateTime Dates)
        {

            ArrayList arrayList3 = new ArrayList();
            arrayList3.Add(Dates);
           
            clsLog.WriteInfoLog("{Info} " + DateTime.Now + " - FS_Helper.INSERTRECORDS - SPNAME -Sp_Montly_BalnceSheet_Reports " + Dates + " - Method Executed.");
            DataSet ds3 = FS_Helper.INSERTRECORDS("Sp_Montly_BalnceSheet_DateWiseReports", arrayList3);
            List<BalanceSheet> BSE = new List<BalanceSheet>();
            for (int i = 0; i < ds3.Tables[0].Rows.Count; i++)
            {
                BalanceSheet BS = new BalanceSheet();
                BS.Name = ds3.Tables[0].Rows[0]["Name"].ToString();
                BS.Date = Convert.ToDateTime(ds3.Tables[0].Rows[0]["Date"].ToString());
                BS.Type = ds3.Tables[0].Rows[0]["Type"].ToString();
                BS.CreditAmt = Convert.ToDecimal(ds3.Tables[0].Rows[0]["CreditAmt"].ToString());
                BS.DebitAmt = Convert.ToDecimal(ds3.Tables[0].Rows[0]["DebitAmt"].ToString());
                BS.Diff = Convert.ToDecimal(ds3.Tables[0].Rows[0]["Diff"].ToString());

                BSE.Add(BS);
            }

            return BSE;

        }

        IEnumerable<BalanceSheet> IDataAcessRepository.GetDailySummary(DateTime Dates)
        {
            throw new NotImplementedException();
        }
    }
}